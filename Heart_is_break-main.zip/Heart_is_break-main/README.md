<h1 align="center"><b>❤️ SHIZUKA MUSIC ❤️</b></h1>

<h4 align="center">Shizuka A Powerful, Smart And Simple Bot To Play Audio And Video Song In Telegram<br> ... Written With Python and Telethon...</h4>

<p align="center"><a href="https://telegram.dog/its_star_boi"><img src="https://te.legra.ph/file/159d3f9e2d57dd02db970.jpg" width="400"></a></p>

<p align="center">

<a href="https://github.com/itz-star-boi/ShizukaXMusic"> 
<img src="https://img.shields.io/github/repo-size/itz-star-boi/ShizukaXMusic?color=orange&logo=github&logoColor=green&style=for-the-badge" /></a>

<a href="https://github.com/itz-star-boi/ShizukaXMusic/commits/prince"> 
<img src="https://img.shields.io/github/last-commit/itz-star-boi/ShizukaXMusic?color=brown&logo=github&logoColor=green&style=for-the-badge" /></a>

<a href="https://github.com/itz-star-boi/ShizukaXMusic/issues"> 
<img src="https://img.shields.io/github/issues/itz-star-boi/ShizukaXMusic?color=blueviolet&logo=github&logoColor=green&style=for-the-badge" /></a>

<a href="https://github.com/itz-star-boi/ShizukaXMusic/network/members"> 
<img src="https://img.shields.io/github/forks/itz-star-boi/ShizukaXMusic?color=red&logo=github&logoColor=green&style=for-the-badge" /></a>  

<a href="https://pypi.org/project/Telethon/"> 
<img src="https://img.shields.io/pypi/v/telethon?color=yellow&label=telethon&logo=python&logoColor=green&style=for-the-badge" /></a>

</p>

> ⭐️ Thanks to everyone for using Shizuka,  🤭 That is the greatest pleasure we have !

## Features Of Shizuka And Commands ❤️

<details>

<summary><b>ғᴇᴀᴛᴜʀᴇs</b></summary>

<br>

- Thumbnail Support

- Audio And Video

- Gban User

- Showing track names when skipping

- Youtube, Local playback support

- Settings panel

- Control with buttons

- Userbot auto join

- Channel Music Play

- Keyboard selection support for youtube play

- Lyrics Scrapper

- Unlimited Queue

- Broadcast Bot

- Statistic Collector

- Block / Unblock (restrict user for using your bot)

</details>

#### Overall Basic Commands 😂

<details>

<summary><b>ʙᴀsɪᴄ ᴄᴍᴅs</b></summary>

<br>

- `/play <song name>` - play song you requested

- `/playlist` - Show now playing list

- `/song <song name>` - download songs you want quickly

- `/search <query>` - search videos on youtube with details

- `/vsong <song name>` - download videos you want quickly

- `/lyric <song name>` - lyrics scrapper

- `/vk <song name>` - generate song without download

</details>

### Only Admin Can Exicute 🙄

<details>

<summary><b>ᴀᴅᴍɪɴ ᴄᴍᴅs</b></summary>

<br>

- `/player` - open music player settings panel

- `/pause` - pause song play

- `/resume` - resume song play

- `/skip` - play next song

- `/end` - stop music play

- `/ping` - check the bot ping status

- `/auth` - authorized people to access the admin commands

- `/deauth` - deauthorized people to access the admin commands

</details>

### Sudo Commands 🤭

<details>

<summary><b>sᴜᴅᴏ ᴄᴍᴅs ᴏɴʟʏ</b></summary>

<br>

- `/broadcast` - order the assistant to leave all groups

- `/gban` - gban user

</details>

    

### Only Owner 🙈

<details>

<summary><b>ᴏɴʟʏ ᴏᴡɴᴇʀ</b></summary>

<br>

- `/broadcast` - send a broadcast message from the bot

- `/block` - block people for using your bot

- `/unblock` - unblock people you blocked for using your bot

- `/blocklist` - show the list of all people who's blocked for using your bot

</details>

</details>

# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ

<details>

<summary><b>ʀᴇǫᴜɪʀᴇᴍᴇɴᴛs</b></summary>

<br>

    

- [ᴘʏᴛʜᴏɴ𝟹.𝟿](https://www.python.org/downloads/release/python-390/)

- [ᴛᴇʟᴇɢʀᴀᴍ ᴀᴘɪ ᴋᴇʏ](https://docs.pyrogram.org/intro/setup#api-keys)

- [ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ᴛᴏᴋᴇɴ](https://telegram.dog/botfather)

- [ᴍᴏɴɢᴏᴅʙ URI](https://te.legra.ph/How-To-get-Mongodb-URI-04-06)

- [sᴛʀɪɴɢ sᴇssɪᴏɴ](https://telegram.dog/STRING_SESSION_MAKER_BOT)

    

</details>

<details>

<summary><b>sᴄᴀʟɪɴɢᴏ</b></summary>

<br>

ɴᴏᴡ ʏᴏᴜ ᴄᴀɴ ᴅᴇᴘʟᴏʏ sʜɪᴢᴜᴋᴀ ᴍᴜsɪᴄ ᴏɴ sᴄᴀʟɪɴɢᴏ ɪɴᴛʀᴏᴅᴜᴄᴇᴅ ʙʏ 

        

<p align="center"><a href="https://my.scalingo.com/deploy?template=https://github.com/itz-star-boi/ShizukaXMusic"> <img src="https://cdn.scalingo.com/deploy/button.svg" width="220" height="38.45"/></a></p>

    

</details>

<details>

<summary><b>sᴛʀɪɴɢ sᴇssɪᴏɴ</b></summary>

<br>

    

> ʏᴏᴜ'ʟʟ ɴᴇᴇᴅ ᴀ ᴀᴘɪ_ɪᴅ & ᴀᴘɪ_ʜᴀsʜ ɪɴ ᴏʀᴅᴇʀ ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ᴘʏʀᴏɢʀᴀᴍ sᴇssɪᴏɴ. 

> ᴀʟᴡᴀʏs ʀᴇᴍᴇʙᴇʀ ᴛᴏ ᴜsᴇ ɢᴏᴏᴅ ᴀᴘɪ ᴄᴏᴍʙᴏ ᴇʟsᴇ ʏᴏᴜʀ ᴀᴄᴄᴏᴜɴᴛ ᴄᴏᴜʟᴅ ʙᴇ ᴅᴇʟᴇᴛᴇᴅ.

<h4> ɢᴇɴᴇʀᴀᴛᴇ sᴇssɪᴏɴ ᴠɪᴀ ʀᴇᴘʟ: </h4>    

<p><a href="https://replit.com/@AssadAli/String-Session-Generator"><img src="https://img.shields.io/badge/Generate%20On%20Repl-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a></p>

<h4> ɢᴇɴᴇʀᴀᴛᴇ sᴇssɪᴏɴ ᴠɪᴀ ᴛᴇʟᴇɢʀᴀᴍ sᴛʀɪɴɢ-ɢᴇɴ ʙᴏᴛ: </h4>    

<p><a href="https://telegram.dog/STRING_SESSION_MAKER_BOT"><img src="https://img.shields.io/badge/TG%20String%20Gen%20Bot-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a></p>

    

</details>

<details>

<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>

<br>

<i>**[Watch Deploying Tutorial...](https://youtu.be/yfeavn1V20Q)**</i>

> ʜᴇʀᴏᴋᴜ ʜᴀs ᴛᴡᴏ ᴠᴀʀs[ ʜᴇʀᴏᴋᴜ_ᴀᴘɪ_ᴋᴇʏ & ʜᴇʀᴏᴋᴜ_ᴀᴘᴘ_ɴᴀᴍᴇ ] ғᴏʀ ᴜᴘᴅᴀᴛᴇʀ ᴛᴏ ᴡᴏʀᴋ. 

> ʙʏ sᴇᴛᴛɪɴɢ ᴛʜᴏsᴇ ᴛᴡᴏ ᴠᴀʀs ʏᴏᴜ ᴄᴀɴ ɢᴇᴛ ʟᴏɢs ᴏғ ʏᴏᴜʀ ʜᴇʀᴏᴋᴜ ᴀᴘᴘ, sᴇᴛ ᴠᴀʀ, ᴇᴅɪᴛ ᴠᴀʀ, ᴅᴇʟᴇᴛᴇ ᴠᴀʀs , ᴄʜᴇᴄᴋ ᴅʏɴᴏ ᴜsᴀɢᴇ ᴀɴᴅ ᴜᴘᴅᴀᴛᴇ ʙᴏᴛ. 

> ᴛʜᴏsᴇ ᴛᴡᴏ ᴠᴀʀs ᴀʀᴇ ɴᴏᴛ ᴍᴀɴᴅᴀᴛᴏʀʏ, ʏᴏᴜ ᴄᴀɴ ʟᴇᴀᴠᴇ ᴛʜᴇᴍ ʙʟᴀɴᴋ ᴛᴏᴏ. 

    

<h4> ᴄʟɪᴄᴋ ᴛʜᴇ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏᴡ ᴛᴏ ᴅᴇᴘʟᴏʏ ʏᴜᴋᴋɪ ᴏɴ ʜᴇʀᴏᴋᴜ</h4> 

   

<p><a href="https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2Fitz-star-boi%2FShizukaXMusic"><img src="https://img.shields.io/badge/Deploy%20To%20Heroku-red?style=for-the-badge&logo=heroku" width="200"/></a></p>

</details>

<details>

<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ᴠᴘs</b></summary>

<br>

- Get your [Necessary Variables](https://github.com/itz-star-boi/ShizukaXMusic/blob/main/sample.env)

- Upgrade and Update by :

`sudo apt-get update && sudo apt-get upgrade -y`

- Install Ffmpeg by :

`sudo apt-get install python3-pip ffmpeg -y`

- Install required packages by :

`sudo apt-get install python3-pip -y`

- Install pip by :

`sudo pip3 install -U pip`

- Install Node js by :

`curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm`

- Clone the repository by :

`git clone https://github.com/itz-star-boi/ShizukaXMusic && cd ShizukaXMusic`

- Install requirements by :

`pip3 install -U -r requirements.txt`

- Fill your variables in the env by :

`vi sample.env`<br>

Press `I` on the keyboard for editing env<br>

Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br>

- Rename the env file by :

`mv sample.env .env`

- Install screen to keep running your bot when you close the terminal by :

`sudo apt install screen -y`

- Finally run the bot by :

`screen bash start`

<br>

</details>

# Owner And Credit)

<details>

<summary><b>ᴄʀᴇᴅɪᴛ</b></summary>

<br>

## sᴘᴇᴄɪᴀʟ ᴄʀᴇᴅɪᴛ

- [sᴛᴀʀ ʙᴏɪ](https://telegram.dog/its_star_boi)

- [ᴀsᴀᴅ ᴀʟɪ](https://telegram.dog/Dr_Asad_Ali)

- [ʟᴏɢɪ ʟᴀʙ](https://github.com/LOGI-LAB)

- [ʜᴀʀsʜɪᴛ](https://telegram.dog/HarshitSharma361)

- [Abhimanyu](https://telegram.dog/Itz_Venom_xD)

- [ᴍᴀssoᴍ](https://telegram.dog/Kattai_massom)

- [ʏᴜᴋᴋɪ](https://github.com/NotReallyShikhar)

- [ᴀɴᴏɴʏᴍᴏᴜs](https://github.com/TheAnonymous2005)

</details>

<details>

<summary><b>sᴜᴘᴘᴏʀᴛ</b></summary>

<br>

# ❤️ Support<

<a href="https://telegram.me/Star_X_Network"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>

<a href="https://telegram.me/Star_X_Support"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

</details>

## ᴀᴄᴋɴᴏᴡʟᴇᴅɢᴇᴍᴇɴᴛs

<details>

<summary><b>ʟɪʙʀᴀʀɪᴇs</b></summary>

<br>

ᴛʜᴀɴᴋs ᴛᴏ ᴀʟʟ ᴏғ ʏᴏᴜ ғᴏʀ ᴜsɪɴɢ ᴀɴᴅ ᴍᴀᴋɪɴɢ sʜɪᴢᴜᴋᴀ:

- [Pyrogram](https://github.com/pyrogram/pyrogram)

- [Py-Tgcalls](https://github.com/pytgcalls/pytgcalls)

</details>

